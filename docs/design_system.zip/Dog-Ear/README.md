Dog-Ear is a private notebook for physical books: a lexicon, a character graph and page-numbered highlights. It ships as one dark theme across two platforms: **desktop** (1280px design width) and **mobile** (390 × 844). Shared foundations are below. The **Desktop** and **Mobile** sections say what changes per platform, and **Prototype notes** lists the source quirks a build has to decide on.

## Using this system

- Load `tokens.css`, then `components/bundle.css`, then React 18, ReactDOM 18 and `components/bundle.js`. Components are on `window.DogEar` (`DogEar.Button`, `DogEar.Chip`…). Types and props are in `components/index.d.ts`.
- Fonts come from Google Fonts: Manrope 400/600/700/800 and Source Serif 4 (400, 600, 400 italic). Load both on every screen.
- Every component takes `className`, `style` and native attributes. Where a component has a `platform` prop, pass `"mobile"` on phone screens. Never restyle a component to imitate the other platform.
- Read colours, spacing, radii, shadows, sizes and z-index from tokens (`var(--accent)`, `var(--space-16)`, `var(--radius-md)`). Do not paste hex values into components. The categorical palettes (tie types, book covers, labels, avatars) are data: store the hex on the record and render it as-is.

## Content fundamentals

- **Voice:** plain, calm, second person. Speak to "you"; the product never says "we" except where a person stands behind it ("We will send you a one-time link").
- **Case:** sentence case everywhere: titles, buttons, tabs, menu items ("Your books", "Manage tie types", "Export my data"). Uppercase only through the `eyebrow` style.
- **No exclamation marks, no emoji.** Arrows (→) show tie direction, the middle dot (·) separates meta ("7 characters · 10 ties · 3 highlights"), the ellipsis character (…) marks a pending state or a further step ("Listening…", "Link to…", "Manage labels…").
- **Buttons start with a verb** and name the outcome: "Email me a sign-in link", "Create book", "Save highlight", "Delete book", "Copy missing types".
- **Empty states are two sentences:** what is missing, then the next step. "No words yet. Choose Add word to search the dictionary." / "Your shelf is empty. Add the book you are reading now, then start collecting words, characters and highlights."
- **Errors say what to do,** in one sentence ending with a full stop: "Enter a valid email address.", "Add the page number first.", "Give the tie type a name.", "This book already has that tie type."
- **Destructive copy is exact:** the dialog lists what goes ("…with its 7 characters, 10 ties, 3 highlights and 4 words") and promises the Undo ("You can undo right after."). Toasts confirm in a few words: "The Salt Ledger deleted", "Tie removed", "Details saved".
- **Optional fields say so in the label:** "Author (optional)", "What will you read with it? (optional)". Placeholders give an example, not an instruction: "For example, Ines Calloway", "A few words are plenty", "What stuck with you?".
- **Privacy is stated plainly** where it matters: "Your notes are stored privately in your account. Nobody else can read them."

## Colour

- One theme, **Dark**. The ground is `bg`; raised panels are `surface`; a second level (nodes, count pills, pressed fills) is `surface-raised`; selected or hovered fills are `surface-active`. Hairlines are `divider`, panel borders `border`, control borders `border-strong`.
- Text is `text` (16:1 on `bg`); secondary text is `text-muted` (7.4:1 on `bg`, 6.9:1 on `surface`); definitions and notes use `text-secondary`; quotes use `text-quote`.
- **`accent` is the only brand hue.** Use it for primary buttons, the focus ring, the selected section tab and phone tab, text buttons, the selected node ring, the Saved dot, and the Reading status. Text and icons on an accent fill are `on-accent`, never white.
- **Inverse** (`inverse` fill, `on-inverse` text) is reserved for selected chips and toasts. The toast's Undo is `inverse-action`, its × is `inverse-muted`.
- **Status:** `danger` for errors and destructive actions; `warning` for Offline, Pending and Paused. Badge grounds are `warning-badge`, `accent-soft` and `danger-badge`. A status always carries a word or icon as well as its colour.
- **Categorical palettes** (data colours, not UI colours): `palette-*` for tie types and book covers, `label-*` for highlight labels, `avatar-*` for desktop node initials. Each token's note gives the order new items take.
- The tip bar uses `hint-bg`, `hint-border` and `hint-text`; it is the only tinted surface.

## Type

- **Manrope** for everything (`--font-sans`). **Source Serif 4 italic** only for words quoted from a book (`--font-serif`, colour `text-quote`, wrapped in curly quotes).
- Weights: 400 body, 600 controls (buttons, chips, tabs), 700 titles and labels, 800 the wordmark, the display headline and phone sheet titles.
- Negative tracking on large type only: −0.03em display, −0.02em page titles and the wordmark, −0.01em card, dialog and sheet titles. The `eyebrow` style is the one positive-tracked, uppercase style.
- Line height 1.6 for reading copy (`body-sm`, ledes, empty states), 1.5–1.55 for definitions and notes, tight (1.1–1.25) for headlines and card titles; controls use the default.
- Styles live in three groups: **Desktop**, **Mobile** and **Shared**. Use the platform group for headlines, titles, quotes and inputs; the Shared group is identical on both.

## Spacing, size and layout

- Spacing tokens are named by their pixel value (`space-4` … `space-64`). Values are exact from the source, not a strict scale: 14, 18 and 22 are real steps.
- **44px is the floor for anything tappable** (`size-tap`) on both platforms: buttons, inputs, icon buttons, menu items, phone chips. Desktop chips are 36px (`size-chip`), admin chips 40px.
- Stacks inside cards and drawers use 14px gaps (16px in the Your books drawer); button pairs 8px; dialog actions 10px; page sections 24px.

## Shape, borders and depth

- Radii: 10px controls (`radius-md`), 12px tiles, menus and toasts (`radius-lg`), 14px cards, dialogs and the canvas (`radius-xl`), 16px the auth card, 18px sheet tops, pills for chips, badges and nodes, circles for avatars, dots and mic buttons.
- Every panel has a 1px `border` and no shadow. Shadows mark only things that float: the auth card, drawers, sheets, dialogs, menus, popovers, toasts, the canvas toolbar, nodes and the FAB. Use the matching `shadow-*` token.
- Overlays sit behind a 50% black `scrim` (drawers, dialogs). Phone Book sheets have no scrim.

## States

- **Focus:** a 2px solid `accent` outline offset by 2px on every button, input and link (search inputs excepted; see Prototype notes).
- **Hover (desktop only):** primary → `accent-hover`; secondary and icon buttons → `surface-active`; subtle buttons and mic pills → `surface-raised`; book cards → `surface-hover` with `border-hover`; delete icons → `danger-soft` with `danger`.
- **Pressed (phone):** icon buttons fill `surface-active` while pressed; there are no hover states on phone.
- **Selected:** chips invert (`inverse`), segmented tabs fill `surface-active`, section tabs get an accent underline, phone tabs turn `accent`, nodes get an `accent` ring and unrelated nodes and ties fade to 0.3 and 0.14.
- **Listening (dictation):** the field label reads "Listening…" in `accent`, the field border turns `accent`, the mic fills `accent-soft`.
- **Invalid:** the input border turns `danger` and an `ErrorText` appears under it.
- **Offline:** `SyncStatus` turns `warning` and counts the changes waiting.
- No motion is defined in the source. Overlays appear and disappear without transitions.

## Iconography

- 20 stroke icons, copied path for path from the prototypes, are in `DogEar.Icon` and in the Icons asset group. They are stroke-only, round caps and joins, 1.6px on a 20px grid (1.7–1.8px for the mic, mail, check and arrow).
- Icons inherit `currentColor` in components. The feature tiles colour theirs with `palette-blue` (Lexicon), `palette-green` (Character graph) and `palette-yellow` (Highlights).
- Glyphs, not icons, are used for ×, + and − inside small buttons, matching the source.
- No emoji, no icon font. The logo is the folded-page mark plus the word Dog-Ear set in Manrope 800 (`Wordmark`).

## Component map: desktop ↔ mobile

| Job | Desktop | Mobile |
| --- | --- | --- |
| Page frame | `AppShell` + `Container` | `AppShell platform="mobile"` + `ScrollArea`, or `AppHeader` + `AppBody` + `BottomTabBar` |
| Sections of a book | `Tabs` (Lexicon, Characters, Highlights) | `BottomTabBar` (Highlights, Characters, Lexicon) |
| Create / edit form | `Drawer` (right, 440px) | `Drawer placement="bottom"` on Your books; `Sheet` on Book |
| Choice chips | `Chip` (36px) | `Chip size="touch"` (44px) |
| Outline button | `Button variant="subtle"` | `Button variant="subtle" platform="mobile"` |
| Icon button | `IconButton` | `IconButton platform="mobile"` |
| Toast | `Toast` (fixed, bottom centre) | `Toast placement="mobile"` or `"tabbar"` |
| Character node | `CharacterNode` with tie handle | `NodePill` + "Link to…" in a sheet |
| Canvas controls | `CanvasToolbar` | `GraphControls` + `Fab` |
| Lexicon | `WordEntry` + `Suggestion` in a drawer | `SearchField size="touch"` + `WordCard` |
| Highlights | `HighlightRow` | `HighlightCard` |
| Inputs | `TextInput` 15px | `TextInput size="lg"` 16px on Book |
