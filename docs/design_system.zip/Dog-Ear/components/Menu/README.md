# Menu

Dropdown menu anchored 50px below its trigger, right-aligned, 240px min.

**Platforms:** desktop and mobile · **Used on:** I, I2

## Usage

- Escape closes it. Phone adds a `header` line ("Signed in as …"); desktop adds Invite requests for admins.

## Props

`header?: string; children: MenuItem[]`

Every component also forwards `className`, `style` and native attributes to its root element.
