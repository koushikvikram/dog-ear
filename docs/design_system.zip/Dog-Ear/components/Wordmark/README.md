# Wordmark

The folded-page mark and the name Dog-Ear, set in Manrope 800 at 18px.

**Platforms:** desktop and mobile · **Used on:** H, H2, I, I2, L

## Usage

- Top-left of every non-Book screen. `admin` adds the neutral Admin badge (Invite requests).
- Never recolour the mark; it takes `text`.

## Props

`admin?: boolean`

Every component also forwards `className`, `style` and native attributes to its root element.
