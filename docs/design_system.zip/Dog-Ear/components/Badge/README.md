# Badge

Small status pill: neutral (Admin), pending, approved, declined.

**Platforms:** desktop only · **Used on:** L

## Usage

- One or two words. Tone always matches meaning.

## Props

`tone?: "neutral" | "pending" | "approved" | "declined"`

Every component also forwards `className`, `style` and native attributes to its root element.
