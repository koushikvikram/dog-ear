# Field

A label wrapping its control: text-muted label above, 6px gap (13px) on desktop, 4px gap (12px) on phone Book.

**Platforms:** desktop and mobile · **Used on:** H, H2, I, I2, J, K

## Usage

- Mark optional fields in the label: "Author (optional)". The label may be a node, e.g. the accent "Listening…" state.

## Props

`label: ReactNode; platform?: "desktop" | "mobile"; children`

Every component also forwards `className`, `style` and native attributes to its root element.
