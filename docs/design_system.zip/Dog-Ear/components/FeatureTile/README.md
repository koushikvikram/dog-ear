# FeatureTile

Small feature card on Welcome: 22px icon in a palette colour, 15px title, 13px description.

**Platforms:** desktop and mobile · **Used on:** H, H2

## Usage

- Three across on desktop (flex 1 1 150px). Lexicon = palette-blue, Character graph = palette-green, Highlights = palette-yellow.

## Props

`icon: IconName; color: string; title: string; children`

Every component also forwards `className`, `style` and native attributes to its root element.
