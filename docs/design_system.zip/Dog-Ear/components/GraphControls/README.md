# GraphControls

Phone canvas controls stacked top-right: Ties, +, −, Fit, Auto.

**Platforms:** mobile only · **Used on:** K

## Usage

- A warning dot on Ties means some tie types are hidden.

## Props

`hiddenDot?; onTypes; onZoomIn; onZoomOut; onFit; onArrange`

Every component also forwards `className`, `style` and native attributes to its root element.
