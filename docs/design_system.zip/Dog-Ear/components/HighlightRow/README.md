# HighlightRow

Desktop highlight: 26px page numeral, label dot and name, serif quote, thought, mentions in palette-blue.

**Platforms:** desktop only · **Used on:** J

## Usage

- Sorted by page. The whole row opens the edit drawer.

## Props

`page; label; labelColor; quote?; note?; mentions?; onOpen`

Every component also forwards `className`, `style` and native attributes to its root element.
