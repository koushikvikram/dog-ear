# WordCard

Phone lexicon card: 16px headword, definition, muted trash button.

**Platforms:** mobile only · **Used on:** K

## Usage

- Stack with 14px gaps under the search card.

## Props

`word; definition; onRemove`

Every component also forwards `className`, `style` and native attributes to its root element.
