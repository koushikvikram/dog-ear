# TieLabel

Pill on a tie's midpoint with the tie's words, bordered in the tie-type colour; click to edit.

**Platforms:** desktop only · **Used on:** J

## Usage

- Untitled ties read "untitled tie". Fades with its edge when not related to the selection.

## Props

`x; y; color; opacity?; children`

Every component also forwards `className`, `style` and native attributes to its root element.
