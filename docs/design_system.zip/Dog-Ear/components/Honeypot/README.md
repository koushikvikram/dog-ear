# Honeypot

Off-screen spam trap field for the invite request form.

**Platforms:** desktop and mobile · **Used on:** H, H2

## Usage

- Place inside the request form; it renders nothing visible.

## Props

`none`

Every component also forwards `className`, `style` and native attributes to its root element.
