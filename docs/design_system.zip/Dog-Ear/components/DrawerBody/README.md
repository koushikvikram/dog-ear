# DrawerBody

Padded drawer content stack: 8 24 28 padding, 14px gaps.

**Platforms:** desktop only · **Used on:** J

## Usage

- Your books uses a 16px gap variant inline.

## Props

`children`

Every component also forwards `className`, `style` and native attributes to its root element.
