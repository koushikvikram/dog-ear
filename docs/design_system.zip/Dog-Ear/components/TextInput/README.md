# TextInput

The 44px text input; also renders select and textarea via `as`.

**Platforms:** desktop and mobile · **Used on:** H, H2, I, I2, J, K

## Usage

- `ground="page"` when it sits on a card whose inputs read as inset (Welcome, phone Book): bg fill. Default `card` fill = surface (Your books, Book desktop).
- `size="lg"` = 16px text on phone reading screens. `invalid` = coral border with an ErrorText below. `pageNumber` = 84px centred page field.

## Props

`as?: "input" | "select" | "textarea"; ground?: "card" | "page"; size?: "md" | "lg"; invalid?; pageNumber?; ...input props`

Every component also forwards `className`, `style` and native attributes to its root element.
