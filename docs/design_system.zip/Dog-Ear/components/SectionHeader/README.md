# SectionHeader

The heading row of a section in a drawer or sheet: an eyebrow title with an optional count, and an optional accent text action on the right ("Notes (2)" with "+ Add note", "Ties (3)" with "+ Add tie").

**Platforms:** desktop and mobile · **Used on:** J, K

## Usage

- One per section of a character drawer (desktop) or character sheet (phone): Also known as (desktop), Notes, Highlights, Ties. The same row on both platforms.
- The count is the number of items in the section; leave it out when there are none, and say so in the empty state under the row.
- The action adds to the section. It opens an editor or box in place, under the list (a new note card, the add-tie box, the add-name field), or starts a mode (on phone, "+ Add tie" shows the tap-to-link `ActionBanner`). Hide the action while its editor is open, and when there is nothing to add (no other character to tie to).
- Label the action "+ Add" and one noun: "+ Add note", "+ Add tie", "+ Add name". The section title gives the context, so the noun stays short. Never use it for the section's only way to do something destructive.

## Props

`title; count?: number; actionLabel?: string; onAction?: () => void; action?: ReactNode`

`action` replaces the `TextButton` when the right side needs something else. Every component also forwards `className`, `style` and native attributes to its root element.
