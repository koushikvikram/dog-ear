# GraphCanvas

The dotted, pannable canvas for the character graph (22px dot pitch on surface).

**Platforms:** desktop and mobile · **Used on:** J, K

## Usage

- Desktop: `framed` (600px, bordered, radius 14), background size and position follow pan/zoom. Phone: fills the body under the hint.

## Props

`framed?; style; children`

Every component also forwards `className`, `style` and native attributes to its root element.
