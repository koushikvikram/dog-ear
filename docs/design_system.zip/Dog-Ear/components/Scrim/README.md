# Scrim

Full-bleed 50% black button behind drawers and dialogs; clicking it closes them.

**Platforms:** desktop and mobile · **Used on:** I, I2, J

## Usage

- Label it for what it does ("Close", "Cancel").

## Props

`label?: string; onClick`

Every component also forwards `className`, `style` and native attributes to its root element.
