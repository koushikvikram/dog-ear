# ScrollArea

The scrolling body of a phone screen inside a mobile AppShell.

**Platforms:** mobile only · **Used on:** H2, I2

## Usage

- Default padding 16 16 40 (Your books). Welcome uses 20 20 32.

## Props

`style?; children`

Every component also forwards `className`, `style` and native attributes to its root element.
