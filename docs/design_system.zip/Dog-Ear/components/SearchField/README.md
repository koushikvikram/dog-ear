# SearchField

Search box with a leading 18px search icon and a bare input.

**Platforms:** desktop and mobile · **Used on:** I, I2, J, K

## Usage

- `md` (44px) filters Your books; `lg` (52px, 17px text) is the dictionary search in the Add word drawer; `touch` (48px, radius 12, bg fill, 16px) is the phone lexicon search.
- `trailing` takes a MicButton.

## Props

`size?: "md" | "lg" | "touch"; placeholder; label?; value; onChange; trailing?`

Every component also forwards `className`, `style` and native attributes to its root element.
