# HighlightCard

Phone highlight: "p. N", label, trash button, then quote, thought and names.

**Platforms:** mobile only · **Used on:** K

## Usage

- Newest first. Tapping the text opens the Edit highlight sheet.

## Props

`page; label; labelColor; quote?; note?; names?; onOpen; onRemove`

Every component also forwards `className`, `style` and native attributes to its root element.
