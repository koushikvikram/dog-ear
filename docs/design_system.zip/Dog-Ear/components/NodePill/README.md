# NodePill

Phone character node: a 112 × 44 pill with the full name, truncated.

**Platforms:** mobile only · **Used on:** K

## Usage

- Accent ring when selected or picking a link target.

## Props

`x; y; ring; opacity?; children`

Every component also forwards `className`, `style` and native attributes to its root element.
