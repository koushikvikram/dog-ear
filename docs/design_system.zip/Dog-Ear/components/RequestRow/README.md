# RequestRow

An invite request: email with status badge, the note, the date, and its actions.

**Platforms:** desktop only · **Used on:** L

## Usage

- Pending rows get Approve (primary) and Decline (secondary, compact); decided rows get Back to pending.

## Props

`email; status; statusLabel; note; when; actions`

Every component also forwards `className`, `style` and native attributes to its root element.
