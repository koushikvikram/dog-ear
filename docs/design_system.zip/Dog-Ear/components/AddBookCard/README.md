# AddBookCard

Dashed placeholder card that opens the New book drawer when the shelf is empty.

**Platforms:** desktop and mobile · **Used on:** I, I2

## Usage

- Show only when there are no books.

## Props

`children?; onClick`

Every component also forwards `className`, `style` and native attributes to its root element.
