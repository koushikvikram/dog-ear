# SyncStatus

Save state: accent dot + "Saved", or warning dot + "Offline · N waiting".

**Platforms:** desktop and mobile · **Used on:** J, K

## Usage

- Desktop: bordered 32px pill beside the subtitle. Phone: borderless in the AppHeader, shortened to "Offline · N".

## Props

`offline?; platform?; children`

Every component also forwards `className`, `style` and native attributes to its root element.
