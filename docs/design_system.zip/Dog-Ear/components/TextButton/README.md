# TextButton

An accent-coloured text action that reveals more of a form ("+ Add quote", "+ Who is in it?").

**Platforms:** desktop and mobile · **Used on:** J, K

## Usage

- Use for optional disclosure inside a card, never for the main action. Pair with aria-expanded.

## Props

`children; onClick`

Every component also forwards `className`, `style` and native attributes to its root element.
