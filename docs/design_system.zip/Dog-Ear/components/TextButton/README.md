# TextButton

An accent-coloured text action that reveals more of a form ("+ Add quote", "+ Who is in it?") or adds to a section ("+ Add note", "+ Add tie").

**Platforms:** desktop and mobile · **Used on:** J, K

## Usage

- Use for optional disclosure inside a card, never for the main action. Pair with aria-expanded.
- On the right of a section's heading row it adds to that section: use `SectionHeader` with `actionLabel` rather than placing one by hand.

## Props

`children; onClick`

Every component also forwards `className`, `style` and native attributes to its root element.
