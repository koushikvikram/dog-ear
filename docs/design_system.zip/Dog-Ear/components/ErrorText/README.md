# ErrorText

Inline error (role=alert), 13px coral, placed directly under the field or above the submit button.

**Platforms:** desktop and mobile · **Used on:** H, H2, J, K

## Usage

- Say what to do: "Enter a valid email address.", "Add the page number first."

## Props

`children`

Every component also forwards `className`, `style` and native attributes to its root element.
