# AppHeader

The 56px phone header: back arrow, the book title (17px/800, truncated) and a trailing slot for SyncStatus.

**Platforms:** mobile only · **Used on:** K

## Usage

- Only on the phone Book screen; other phone screens use the Wordmark row.

## Props

`title: string; backHref: string; backLabel?: string; trailing?`

Every component also forwards `className`, `style` and native attributes to its root element.
