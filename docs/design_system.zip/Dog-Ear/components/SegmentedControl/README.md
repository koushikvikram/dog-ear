# SegmentedControl

Two-option switch on a bg track (Request an invite / I have an invite).

**Platforms:** desktop and mobile · **Used on:** H, H2

## Usage

- Use for mutually exclusive modes of one card. Equal-width tabs, 44px tall.

## Props

`items: { label; selected?; onClick? }[]; label?: string`

Every component also forwards `className`, `style` and native attributes to its root element.
