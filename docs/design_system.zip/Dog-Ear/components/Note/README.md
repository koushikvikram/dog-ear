# Note

Muted 14px helper line inside a drawer list ("Start typing to see words and their meanings.").

**Platforms:** desktop only · **Used on:** J

## Usage

- For drawer-level guidance and no-match messages.

## Props

`children`

Every component also forwards `className`, `style` and native attributes to its root element.
