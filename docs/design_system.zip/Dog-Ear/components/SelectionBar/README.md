# SelectionBar

Line under the desktop canvas naming the selected character with Edit card and Remove.

**Platforms:** desktop only · **Used on:** J

## Usage

- Keyboard and non-double-click route to the selected node.

## Props

`children`

Every component also forwards `className`, `style` and native attributes to its root element.
