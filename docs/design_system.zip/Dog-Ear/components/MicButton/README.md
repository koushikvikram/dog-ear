# MicButton

Round 44px dictation button that sits inside a text field.

**Platforms:** desktop and mobile · **Used on:** J, K

## Usage

- Muted when idle; `on` (listening) fills with `accent-soft` and turns `accent`, and the field label reads "Listening…" in accent with an accent border.
- Position it absolutely at the field's bottom-right (6px inset) and pad the field 58px on the right.

## Props

`on?: boolean; label?: string`

Every component also forwards `className`, `style` and native attributes to its root element.
