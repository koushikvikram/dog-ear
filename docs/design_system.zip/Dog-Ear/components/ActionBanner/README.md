# ActionBanner

Accent banner for a pending pick ("Tap who Mara Vell is tied to") with Cancel.

**Platforms:** mobile only · **Used on:** K

## Usage

- Over the phone canvas while linking two characters.

## Props

`children; action`

Every component also forwards `className`, `style` and native attributes to its root element.
