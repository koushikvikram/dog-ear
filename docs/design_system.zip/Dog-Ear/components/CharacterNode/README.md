# CharacterNode

Desktop character node: avatar initial, first name and job, with the green handle that starts a tie.

**Platforms:** desktop only · **Used on:** J

## Usage

- Ring: border-strong; accent when selected; on-avatar (white) when a dragged tie will land on it. Unrelated nodes fade to 0.3 while one is selected.
- Avatar colours cycle avatar-green, -blue, -red, -violet, -brown, -teal.

## Props

`x; y; name; first; job; initial; avatar; ring; opacity?; nodeProps?; handleProps?`

Every component also forwards `className`, `style` and native attributes to its root element.
