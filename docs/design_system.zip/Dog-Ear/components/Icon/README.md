# Icon

The 20 stroke icons the prototypes draw, copied path for path.

**Platforms:** desktop and mobile · **Used on:** All screens

## Usage

- Stroke-only in `currentColor` unless `stroke` is passed. Sizes as used: 14 (close, arrow), 16 (plus, back, mic-sm, trash on phone), 18 (search, edit, trash, mail), 20 (logo, mic), 22 (features, tab bar, FAB).
- Names: logo, lexicon, graph, highlight, highlight-tab, pencil, trash, trash-simple, search, plus, close, back, chevron-down, chevron-down-wide, mic, mic-sm, mail, check, arrow-right, eye.

## Props

`name: IconName; size?: number; stroke?: string; strokeWidth?: number`

Every component also forwards `className`, `style` and native attributes to its root element.
