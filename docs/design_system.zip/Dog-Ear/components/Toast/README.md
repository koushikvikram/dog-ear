# Toast

Inverse status message with optional Undo and a × dismiss.

**Platforms:** desktop and mobile · **Used on:** I, I2, J, K, L

## Usage

- Desktop: fixed, bottom-centre, 24px up. Phone: inside the shell, 12px side insets (`mobile`), or above the tab bar (`tabbar`).
- Every destructive action ends in a toast with Undo instead of a second confirmation.

## Props

`message; placement?: "fixed" | "mobile" | "tabbar"; actionLabel?; onAction?; onDismiss`

Every component also forwards `className`, `style` and native attributes to its root element.
