# Drawer

Desktop: 440px panel from the right. Phone (`placement="bottom"`): the same content as a bottom sheet, max 88% tall.

**Platforms:** desktop and mobile · **Used on:** I, I2, J

## Usage

- Use for create/edit forms and pickers that keep the page visible. One drawer at a time; always behind a Scrim.
- Header is DrawerHeader (muted 14px context line + close); body is DrawerBody or a 16px-gap stack.

## Props

`placement?: "right" | "bottom"; children`

Every component also forwards `className`, `style` and native attributes to its root element.
