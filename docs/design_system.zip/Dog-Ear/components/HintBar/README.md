# HintBar

Dismissible green-tinted tip explaining a gesture-heavy surface (the character canvas).

**Platforms:** desktop and mobile · **Used on:** J, K

## Usage

- One per screen, above the surface it explains. Dismissal sticks.

## Props

`platform?; onDismiss; children`

Every component also forwards `className`, `style` and native attributes to its root element.
