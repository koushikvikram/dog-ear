# Tabs

Underlined section tabs with count pills (Lexicon, Characters, Highlights).

**Platforms:** desktop only · **Used on:** J

## Usage

- The selected tab gets `text` and a 2px accent underline; others are muted.
- On phone the same sections move to the BottomTabBar.

## Props

`items: { label; count?; selected?; onClick? }[]`

Every component also forwards `className`, `style` and native attributes to its root element.
