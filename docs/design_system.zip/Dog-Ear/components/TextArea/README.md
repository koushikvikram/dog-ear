# TextArea

Multi-line field on a page ground: 88px, vertical resize (Welcome); `size="lg"` = 84px, 16px, no resize (phone Book).

**Platforms:** desktop and mobile · **Used on:** H, H2, K

## Usage

- On desktop Book the textareas are TextInput `as="textarea"` on the card ground.

## Props

`size?: "md" | "lg"; ...textarea props`

Every component also forwards `className`, `style` and native attributes to its root element.
