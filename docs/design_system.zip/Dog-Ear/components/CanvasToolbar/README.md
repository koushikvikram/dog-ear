# CanvasToolbar

Bottom-right canvas toolbar: zoom out, zoom %, zoom in, Fit, Auto-arrange.

**Platforms:** desktop only · **Used on:** J

## Usage

- Zoom range 20–250% in 1.25× steps; Ctrl/⌘ + scroll zooms around the cursor.

## Props

`zoom: string; onZoomIn; onZoomOut; onFit; onArrange`

Every component also forwards `className`, `style` and native attributes to its root element.
