# AppBody

The positioned, scrolling middle of the phone Book screen, between AppHeader and BottomTabBar.

**Platforms:** mobile only · **Used on:** K

## Usage

- Sheets and the tab-bar toast are positioned against it.

## Props

`children`

Every component also forwards `className`, `style` and native attributes to its root element.
