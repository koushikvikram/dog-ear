# IconButton

A 44 × 44 button holding one icon or glyph: close, dismiss, remove.

**Platforms:** desktop and mobile · **Used on:** I, I2, J, K

## Usage

- Desktop: muted, radius 8, `surface-active` fill on hover.
- Mobile (`platform="mobile"`): `text` colour, radius 10, fill only while pressed; `muted` for remove/trash.
- Always pass `label`; it becomes the aria-label.

## Props

`label: string; platform?: "desktop" | "mobile"; muted?; icon?: IconName (default close); iconSize?: number; children?`

Every component also forwards `className`, `style` and native attributes to its root element.
