# AccountButton

The account button with initial disc, email (desktop only) and chevron; opens the Menu.

**Platforms:** desktop and mobile · **Used on:** I, I2

## Usage

- Desktop shows the email; phone shows only the disc and chevron and moves the email into the menu header.

## Props

`initial?: string; email?: string; expanded?: boolean`

Every component also forwards `className`, `style` and native attributes to its root element.
