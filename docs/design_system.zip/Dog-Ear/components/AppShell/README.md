# AppShell

The page frame: bg ground, Manrope, text colour, and the positioning context for scrims, drawers, sheets and dialogs.

**Platforms:** desktop and mobile · **Used on:** All screens

## Usage

- Desktop: `<AppShell>` grows with content, min-height 820px (pass `minHeight="900px"` on Book).
- Mobile: `<AppShell platform="mobile">` is a fixed 844px flex column; put a `ScrollArea` (Welcome, Your books) or `AppHeader` + `AppBody` + `BottomTabBar` (Book) inside.

## Props

`platform?: "desktop" | "mobile"; minHeight?: string; children`

Every component also forwards `className`, `style` and native attributes to its root element.
