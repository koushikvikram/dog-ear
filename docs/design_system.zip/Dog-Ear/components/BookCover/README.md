# BookCover

The 56 × 76 coloured book block with the title initial and a spine shadow.

**Platforms:** desktop and mobile · **Used on:** I, I2

## Usage

- New books take the next book-cover colour: blue, yellow, green, pink, violet, cyan, coral, sand.

## Props

`color: string; initial: string`

Every component also forwards `className`, `style` and native attributes to its root element.
