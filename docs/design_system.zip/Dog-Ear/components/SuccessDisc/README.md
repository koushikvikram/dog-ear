# SuccessDisc

36px accent-soft disc with a check or mail icon, beside a result title.

**Platforms:** desktop and mobile · **Used on:** H, H2

## Usage

- Only for confirmed outcomes (Check your email, Request received).

## Props

`icon?: "check" | "mail"`

Every component also forwards `className`, `style` and native attributes to its root element.
