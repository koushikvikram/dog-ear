# MenuItem

A 44px row inside Menu; `href` makes it a link.

**Platforms:** desktop and mobile · **Used on:** I, I2

## Usage

- Short verb phrases in sentence case.

## Props

`href?: string; onClick?; children`

Every component also forwards `className`, `style` and native attributes to its root element.
