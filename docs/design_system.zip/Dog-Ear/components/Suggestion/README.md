# Suggestion

Dictionary suggestion row in the Add word drawer; `hot` marks the keyboard-highlighted row.

**Platforms:** desktop only · **Used on:** J

## Usage

- Arrow keys move `hot`; Enter adds. Words already in the book show the accent "Saved" badge.

## Props

`word; pos; definition; badge?; hot?`

Every component also forwards `className`, `style` and native attributes to its root element.
