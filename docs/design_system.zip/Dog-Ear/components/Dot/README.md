# Dot

A colour dot: 10px for tie types and labels on desktop, 8px for statuses and phone chips, 12px in the phone label picker.

**Platforms:** desktop and mobile · **Used on:** I, I2, J, K

## Usage

- Always next to a word; colour alone never carries the meaning.

## Props

`color: string; size?: 8 | 10 | 12`

Every component also forwards `className`, `style` and native attributes to its root element.
