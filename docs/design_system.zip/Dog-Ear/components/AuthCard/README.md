# AuthCard

The Welcome card: 420px (full width on phone), radius 16, 24px padding, the only element with shadow-card.

**Platforms:** desktop and mobile · **Used on:** H, H2

## Usage

- Holds the SegmentedControl and one form or result state at a time.

## Props

`platform?: "desktop" | "mobile"; children`

Every component also forwards `className`, `style` and native attributes to its root element.
