# BottomTabBar

The 64px phone tab bar: Highlights, Characters, Lexicon with 22px icons.

**Platforms:** mobile only · **Used on:** K

## Usage

- Selected item turns accent. Order on phone is Highlights first (the reading task), unlike desktop.

## Props

`items: { label; icon: IconName; selected?; onClick? }[]`

Every component also forwards `className`, `style` and native attributes to its root element.
