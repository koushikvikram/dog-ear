# MicPill

Bordered "Dictate" pill beside a field label in the desktop highlight drawer.

**Platforms:** desktop only · **Used on:** J

## Usage

- `recording` turns it coral with the label "Listening. Tap to stop".

## Props

`recording?: boolean; children?`

Every component also forwards `className`, `style` and native attributes to its root element.
