# WordEntry

Desktop lexicon row: 19px headword, part of speech, definition, remove button, hairline below.

**Platforms:** desktop only · **Used on:** J

## Usage

- Removing shows an Undo toast.

## Props

`word; pos; definition; onRemove`

Every component also forwards `className`, `style` and native attributes to its root element.
