# Panel

Bordered surface card: 18px padding on desktop (quick capture, drawer sub-forms), 14 16 on phone (every phone card).

**Platforms:** desktop and mobile · **Used on:** J, K

## Usage

- Use for a self-contained form or item inside a page or drawer.

## Props

`platform?: "desktop" | "mobile"; children`

Every component also forwards `className`, `style` and native attributes to its root element.
