# Button

The four button kinds: primary (accent fill), secondary (outline, 15px), subtle (outline, 14px) and danger (coral fill).

**Platforms:** desktop and mobile · **Used on:** All screens

## Usage

- One primary per region, for the thing the region is for. Verb first, sentence case ("Create book", "Save highlight").
- secondary is the Welcome/Library/Admin outline button (Cancel, Use a different email, Decline); `compact` gives Admin's 16px side padding.
- subtle is the Book screens' outline button (Manage labels, Swap, Open, Cancel). `tone="danger"` makes the outline destructive button (Remove, Remove tie). `size="sm"` = 36px / 13px. `platform="mobile"` = phone sizing (14px side padding, no gap, phone danger border).
- danger fill is only for the confirming button of a destructive dialog ("Delete book").
- `icon="plus"` puts the 16px icon before the label. `href` renders an <a>. `block` = full width.

## Props

`variant?: "primary" | "secondary" | "subtle" | "danger"; tone?: "danger"; size?: "sm"; platform?: "desktop" | "mobile"; block?; compact?; on?; icon?: IconName; href?: string`

Every component also forwards `className`, `style` and native attributes to its root element.
