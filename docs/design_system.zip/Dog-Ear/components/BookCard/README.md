# BookCard

A book on the shelf: cover, title, author, status and last-opened, last highlight and counts, plus edit and delete buttons.

**Platforms:** desktop and mobile · **Used on:** I, I2

## Usage

- Cards wrap at flex 1 1 300px with 16px gaps (one column on phone). The whole card links to the book.
- Status dot colour: status-reading, status-finished, status-paused.

## Props

`title; author?; color; status; statusColor; opened; lastHighlight; counts: { chars; ties; hl; words }; href; onEdit; onDelete`

Every component also forwards `className`, `style` and native attributes to its root element.
