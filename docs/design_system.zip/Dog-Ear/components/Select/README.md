# Select

Native select styled as a TextInput.

**Platforms:** desktop and mobile · **Used on:** I, I2, J, K

## Usage

- Start with a neutral first option ("Start with none", "Choose a book").

## Props

`same as TextInput; children: <option>`

Every component also forwards `className`, `style` and native attributes to its root element.
