# Chip

Pill-shaped filter and choice chip; selected chips invert to a light fill.

**Platforms:** desktop and mobile · **Used on:** I, I2, J, K, L

## Usage

- `size="md"` (36px) for desktop filters and choices; `"lg"` (40px, 14px text) with `count` for admin filters; `"touch"` (44px, 6px gap, 8px dot) on phone.
- `dot` adds the leading colour dot for tie types and highlight labels. `add` is the dashed accent "+ Add" chip.
- Chips are toggle buttons (aria-pressed). Use them for filters, statuses, labels, tie types and mentions, not for actions.

## Props

`selected?; size?: "md" | "lg" | "touch"; dot?: string; count?: number; add?`

Every component also forwards `className`, `style` and native attributes to its root element.
