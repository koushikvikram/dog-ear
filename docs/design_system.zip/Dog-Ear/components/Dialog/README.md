# Dialog

Centred 420px alert dialog for destructive confirmation.

**Platforms:** desktop and mobile · **Used on:** I, I2

## Usage

- Title asks the question ("Delete The Salt Ledger?"); body states exactly what goes and that Undo follows; Cancel (secondary, autofocus) then the danger button. Escape cancels.

## Props

`title; titleId?; children; actions`

Every component also forwards `className`, `style` and native attributes to its root element.
