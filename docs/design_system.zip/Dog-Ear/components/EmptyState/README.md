# EmptyState

Muted 15px/1.6 paragraph for empty lists and no-match results.

**Platforms:** desktop and mobile · **Used on:** I, I2, J, K, L

## Usage

- Two short sentences: what is missing, then how to fill it ("No words yet. Choose Add word to search the dictionary.").

## Props

`children`

Every component also forwards `className`, `style` and native attributes to its root element.
