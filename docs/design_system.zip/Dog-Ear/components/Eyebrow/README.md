# Eyebrow

Uppercase 12px/700 label with 0.06em tracking for groups of controls (Status, Tie type, Quick capture).

**Platforms:** desktop and mobile · **Used on:** H, I, J, K

## Usage

- Muted by default; the Welcome "Invite only" eyebrow is accent.

## Props

`as?: "div" | "span"; children`

Every component also forwards `className`, `style` and native attributes to its root element.
