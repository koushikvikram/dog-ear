# SwatchRow

A row of a manage list (tie types, highlight labels): colour swatch that cycles, name input, count, delete.

**Platforms:** desktop and mobile · **Used on:** J, K

## Usage

- Desktop rows have a hairline and 40px input; phone rows use the 16px page-ground input and may lead with an eye toggle (tie types).

## Props

`platform?; color; name; count?; onCycle; onRename; onRemove; inputLabel?; removeLabel?; leading?; swatchSize?`

Every component also forwards `className`, `style` and native attributes to its root element.
