# DrawerHeader

Drawer top row: a muted context line ("Add to The Salt Ledger") and the close button.

**Platforms:** desktop and mobile · **Used on:** I, I2, J

## Usage

- The context line says where the content goes, not a big title.

## Props

`title; onClose`

Every component also forwards `className`, `style` and native attributes to its root element.
