# Fab

The 56px accent add button pinned bottom-right of the phone character canvas.

**Platforms:** mobile only · **Used on:** K

## Usage

- Hide it while a character is selected or a sheet is open.

## Props

`label?: string`

Every component also forwards `className`, `style` and native attributes to its root element.
