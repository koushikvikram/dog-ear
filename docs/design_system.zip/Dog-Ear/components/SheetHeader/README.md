# SheetHeader

Sheet title (17px/800) with optional actions and a close button.

**Platforms:** mobile only · **Used on:** K

## Usage

- Keep titles to a noun: "Label", "Tie types", "Edit highlight".

## Props

`title; onClose?; actions?`

Every component also forwards `className`, `style` and native attributes to its root element.
