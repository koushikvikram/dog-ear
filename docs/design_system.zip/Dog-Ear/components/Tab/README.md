# Tab

One underlined tab; Tabs is a row of these, and the tie popover header uses two directly.

**Platforms:** desktop only · **Used on:** J

## Usage

- Popover tabs override the right margin (12px, then 0).

## Props

`selected?; count?; children`

Every component also forwards `className`, `style` and native attributes to its root element.
