# Popover

380px panel over the character canvas for editing one tie or the tie types.

**Platforms:** desktop only · **Used on:** J

## Usage

- Opens under the tie label it edits, clamped inside the canvas. Header row of Tabs + close.

## Props

`label; style (left, top, maxHeight); children`

Every component also forwards `className`, `style` and native attributes to its root element.
