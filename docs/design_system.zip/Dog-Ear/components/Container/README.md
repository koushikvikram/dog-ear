# Container

Centred desktop content column with the 40px side padding.

**Platforms:** desktop only · **Used on:** H, I, J, L

## Usage

- `width="wide"` (1120px) on Welcome, default (1080px) on Your books and Book, `"narrow"` (960px) on Invite requests.
- Default padding is 36 40 64. Welcome uses 32 40 56, Book 36 40 56, Admin 32 40 64: pass them as `style.padding`.

## Props

`width?: "wide" | "default" | "narrow"; style?; children`

Every component also forwards `className`, `style` and native attributes to its root element.
