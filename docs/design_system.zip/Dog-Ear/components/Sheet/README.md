# Sheet

Phone bottom sheet docked above the 64px tab bar, radius 18 on top, max 520px (600px for long forms).

**Platforms:** mobile only · **Used on:** K

## Usage

- Use for every phone Book overlay: character, tie, label picker, labels, tie types, edit highlight, character details. No scrim; one sheet at a time.

## Props

`label: string; children`

Every component also forwards `className`, `style` and native attributes to its root element.
