# Desktop

Design width 1280px. The shell is at least 820px tall (900px on Book) and the page scrolls as a whole. Four screens: Welcome (H), Your books (I), Book (J) and Invite requests (L).

## Layout

- Wrap every screen in `AppShell`, then one `Container` with 40px side padding.
  - Welcome: `width="wide"` (1120px), padding 32 40 56.
  - Your books: default (1080px), padding 36 40 64.
  - Book: default (1080px), padding 36 40 56, `AppShell minHeight="900px"`.
  - Invite requests: `width="narrow"` (960px), padding 32 40 64.
- **Top row:** `Wordmark` on the left; on the right, the screen's global control (book count + `AccountButton`, or the "Your books" back button). On Book the row is the back button (`Button variant="subtle"` with the back icon) and the book switcher (subtle button with `chevron-down-wide`).
- **Title block:** 40px above (28px on Book), 24px below (20px on Admin). `desktop-title` h1, then a 14px `text-muted` line 6px under it. The screen's primary action sits right-aligned on the title's baseline row (`align-items: flex-end`).
- **Welcome:** hero (flex 1 1 440px) and `AuthCard` (420px) side by side with a 56px gap, 56px above and 40px below; the three `FeatureTile`s sit 32px under the lede; a hairline footer closes the page.
- **Grids:** book cards and feature tiles wrap with `flex: 1 1 300px` / `1 1 150px` and 16px / 12px gaps. Request rows stack with 12px gaps.

## Navigation and overlays

- Book sections are `Tabs` 18px under the title block, with a `divider` underline.
- Forms open in a **right `Drawer`** (440px, full height, `shadow-drawer`) behind a `Scrim`. The header is a muted context line ("New book", "Add to The Salt Ledger") with a close button; the body stacks fields with 14–16px gaps and ends with the primary button.
- **Destructive confirmation** is a `Dialog` (420px, centred) with Cancel (secondary, autofocus) and the danger fill button. Escape cancels.
- **Toasts** are fixed bottom-centre, 24px from the bottom, and carry Undo for anything removed.
- The **account menu** drops 50px below the account button, right-aligned: Export my data, Invite requests (admins), Sign out.

## Character canvas

- `GraphCanvas framed` (600px tall, radius 14) with a 22px dot grid that pans and zooms with the content.
- `HintBar` above it, then a "Show ties" row of tie-type `Chip`s with dots that toggle visibility.
- `CharacterNode`s carry the green handle: drag from it to another node to create a tie; Enter on it opens the character drawer.
- Ties are quadratic curves with a 14px arrowhead (one at each end for a two-way tie), 2.5px (3.5px when related to the selection), dashed by tie type (none, 8 6, 2 5, 10 4 2 4; untyped 3 4). Each tie has a `TieLabel`; clicking it opens the tie `Popover` (380px) under the label.
- The tie `Popover`: the two names with → (↔ for a two-way tie) and Swap (one way only); Direction chips ("One way →", "Both ways ↔"); the words ("Elara is…", or "Elara and Mara are…" both ways) with earlier words as chips; Tie type chips. When two characters have a tie drawn each way, the popover offers to merge them into one two-way tie, keeping the words you pick, and a line under "Show ties" counts such pairs with a Review link.
- `CanvasToolbar` sits bottom-right (14px inset). Zoom runs from 20% to 250% in 1.25× steps; Ctrl/⌘ + scroll zooms around the pointer.
- Selecting a node shows the `SelectionBar` under the canvas (Edit card, Remove).
- **The character drawer** (Edit card, a double-click or Enter on a node): name with Rename, then **Also known as**, role and first page, then **Notes**, **Highlights** and **Ties**; each of the four sits under a `SectionHeader`. Remove character ends the drawer.
  - Also known as shows the other names as removable chips. "+ Add name" opens a one-line field (placeholder "For example, The Cartographer") with Add: Enter adds a name and keeps the field open for the next; Escape, or leaving it empty, closes it. A name the character already has is refused ("Elara already goes by Ellie.").
  - Notes are `Panel` cards with an optional page. "+ Add note" opens an editor at the end (Cancel, Add note); clicking a card edits it; its trash deletes it with Undo; dragging a card reorders the list, the others sliding aside (Alt+↑/↓ from the keyboard).
  - Highlights lists every `HighlightRow` that tags the character, by page, with who else is in it; choosing one opens it on the Highlights tab.
  - Ties lists each tie (opens the tie popover) with Open (selects the other character). "+ Add tie" opens a `Panel` under the list: a "Elara is tied to" `Select`, then Cancel and Add tie; adding opens the tie popover. The box is never shown until asked for.

## Highlights

- Quick capture is a `Panel`: page field (92px wide, 24px bold numerals) beside the thought textarea with a `MicButton`; `TextButton`s reveal the quote (serif italic) and "Who is in it?" chips; label chips; a full-width "Save highlight"; a helper line. Enter saves, Shift+Enter adds a line.
- The list is `HighlightRow`s sorted by page, filtered by label chips with counts ("All 3", "Clue 1").

## Hover

Desktop has hover states on every control (see the brand book's States). Book cards, icon buttons and delete buttons all show theirs; keep them.
