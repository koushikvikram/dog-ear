# Logos

- `dog-ear-mark.svg`: the folded-page mark, 20 × 20, 1.6px stroke with round joins, ink `text` (#ECECEE). Always 20px beside the name, with an 8px gap.
- `dog-ear-wordmark.svg`: the mark with "Dog-Ear" set in Manrope 800, 18px, −0.02em, ink `text`. The name is live text, so Manrope must be loaded wherever the file is shown; in the app use the `Wordmark` component.

There is no separate brand logo in the source: the product is identified by this mark and the name in type.
