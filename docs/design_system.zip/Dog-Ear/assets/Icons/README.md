# Icons

The 20 stroke icons from the prototypes, one SVG each, ink `text` (#ECECEE). In code use `DogEar.Icon` instead: it draws the same paths in `currentColor`.

- 20 × 20 grid, 1.6px stroke, round caps and joins: `logo`, `lexicon`, `graph`, `highlight` (feature tile), `highlight-tab` (phone tab bar), `pencil` (edit book), `trash` (desktop delete), `trash-simple` (phone delete), `search` (round caps only), `eye` (phone tie-type visibility).
- 20 × 20, 1.7px: `mic` (in-field dictation). 1.8px: `mail`, `check` (auth result discs).
- 16 × 16, 1.6px: `plus`, `close`, `back`, `mic-sm` (desktop mic pill).
- 12 × 12, 1.6px: `chevron-down` (account button), `chevron-down-wide` (book switcher).
- 14 × 14, 1.8px: `arrow-right` (tie handle on a character node).
