# Mobile

Design size 390 × 844. The shell is a fixed-height flex column (`AppShell platform="mobile"`); content scrolls inside it, never the page. Three screens: Welcome (H2), Your books (I2) and Book (K). Invite requests is desktop-only.

## Layout

- **Welcome and Your books:** `AppShell platform="mobile"` → `ScrollArea` (padding 20 20 32 on Welcome, 16 16 40 on Your books) → the same top row as desktop.
  - Welcome stacks hero, `AuthCard platform="mobile"` (full width) and then the feature tiles, with 24px gaps; the headline is `mobile-display` (32px) and the lede `mobile-lede` (16px).
  - Your books keeps the desktop structure in one column: title `mobile-title` (28px), New book under it, search, filter chips and book cards at full width.
  - The `AccountButton` drops the email; the `Menu` gets the header "Signed in as you@example.com" and loses Invite requests.
- **Book:** an app layout instead of a page:
  - `AppHeader` (56px): back arrow, the book title (17px/800, truncated), `SyncStatus platform="mobile"` ("Saved" / "Offline · N").
  - `AppBody`: each section is a 14 12 24 padded stack of `Panel platform="mobile"` cards with 14px gaps; the Characters section fills the body with the canvas.
  - `BottomTabBar` (64px): Highlights, Characters, Lexicon. The order puts capture first because the phone is used while reading.

## Touch rules

- Every chip on phone is `size="touch"` (44px, 6px gap, 8px dot) and does not wrap its label.
- Inputs and textareas on the Book screen are `size="lg"` (16px) so iOS does not zoom; their ground is `page` (`bg`), inset inside `surface` cards.
- Labels on Book fields are 12px with a 4px gap (`Field platform="mobile"`).
- No hover states. Icon buttons fill `surface-active` only while pressed.
- Outline buttons use `Button variant="subtle" platform="mobile"` (14px side padding, `danger-line-mobile` for Remove).

## Overlays

- **Your books:** the New/Edit book form is the same drawer content as desktop, presented as `Drawer placement="bottom"` (radius 18 on top, max 88% tall, `shadow-sheet`) behind a `Scrim`. The delete `Dialog` is unchanged (it narrows to the screen minus 32px).
- **Book:** every overlay is a `Sheet` docked above the tab bar (bottom 64px, radius 18 on top, max 520px; 600px for Edit highlight and Tie types), with no scrim. One sheet at a time: character, tie, label picker, labels, tie types, edit highlight, character details. Titles are 17px/800 nouns with a close button.
- **Toasts** live inside the shell: `placement="mobile"` (12px insets, 16px from the bottom) on Your books, `placement="tabbar"` (76px from the bottom, message stretches) on Book.

## Character canvas

- The canvas fills `AppBody` under the `HintBar platform="mobile"`, with a 22px dot grid. It starts at 82% zoom; zoom runs 35–180% in 1.2× steps.
- Nodes are `NodePill`s (112 × 44, full name, truncated). Ties are straight 2px lines with an 11px arrowhead and an 11px/700 label in the tie colour with a 4px `surface` halo; dashes follow the tie type.
- Tapping a node opens its sheet: name, job and first page, aliases, notes, ties (each opens the tie sheet), then **Link to…**, Edit, Remove. "Link to…" shows the accent `ActionBanner` ("Tap who Mara Vell is tied to") until a second node is tapped; the tie sheet then asks for type and note.
- `GraphControls` stack top-right (Ties, +, −, Fit, Auto); a warning dot on Ties means some types are hidden. The `Fab` (56px) adds a character and hides while anything is selected or open.

## Lexicon and highlights

- Lexicon: a `Panel` with an eyebrow ("Look up or add a word", or "Listening… say one word" in accent), `SearchField size="touch"` with a 40px `MicButton`, up to three results each with an Add / Added primary button; saved words are `WordCard`s.
- Highlights: quick capture mirrors desktop at phone sizes (84px page field with 22px numerals; labels as touch chips plus a dashed "+ Add" chip that opens the labels sheet); saved highlights are `HighlightCard`s, newest first, each with a trash button and tap-to-edit.
