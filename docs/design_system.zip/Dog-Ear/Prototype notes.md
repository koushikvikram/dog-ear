# Prototype notes

The tokens and components reproduce the seven prototypes exactly, including their small inconsistencies. These are the places where the source disagrees with itself or with accessibility guidance; decide each one deliberately in the build.

## Kept exactly as drawn

- **Two outline-danger borders:** `danger-line` (#5A2F2B) on desktop and `danger-line-mobile` (#5A3330) on phone. Merge them if the difference is unintended.
- **Two on-danger inks:** `on-danger` (#2A0D0A) on the Delete book button and `on-danger-rec` (#2A0E0B) on the recording mic pill.
- **Two outline buttons:** `secondary` (15px, used on Welcome, Your books and Invite requests) and `subtle` (14px, used on Book). Invite requests uses 16px side padding (`compact`) where the others use 18px.
- **Input grounds:** inputs sit on `bg` on Welcome and phone Book, but on `surface` on Your books and desktop Book (`TextInput ground`).
- **Input size:** 15px everywhere except phone Book (16px). Phone Welcome and Your books keep 15px, so iOS will zoom into those fields; consider `size="lg"` there too.
- **Control borders:** `border-strong` is 1.7:1 on `bg` and 1.6:1 on `surface`, under the 3:1 WCAG asks for control boundaries.
- **Search fields hide the focus ring** (`outline: none` on the bare input). Keyboard users get no visible focus there; consider moving the ring to the `SearchField` wrapper with `:focus-within`.
- **Link-styled buttons are 46px tall:** a subtle button rendered as `<a>` (the Book back button) uses content-box sizing, so its 1px border adds 2px to the 44px minimum. A `<button>` is 44px.
- **Phone Book loads only Manrope** in its prototype, so its serif quotes fell back to Georgia. The design system and the demo load Source Serif 4 on every screen.

## Prototype-tool artefacts the demo does not copy

The prototypes were rendered by a design tool that wraps every bound value in its own `<span>`. Three visible glitches come from that, not from the design. The demo shows the intended result instead:

- **Phone character graph:** tie labels ("taught her", "sisters", "Rival", "owes money") never appear, because the span cannot render inside SVG text. The template clearly draws them (11px/700 in the tie colour with a `surface` halo), so the demo shows them.
- **Desktop Book drawers:** the character Notes field and the highlight Quote and Thought fields show "[object Object]" instead of their text. The demo shows the stored text.
- **Tie popover label:** "Elara is…" breaks onto two lines ("Elara" / "is…") because the bound name became its own flex item. The demo keeps it on one line.

Everything else in the demo matched its prototype pixel for pixel in a headless-Chrome comparison of 63 screen states.
